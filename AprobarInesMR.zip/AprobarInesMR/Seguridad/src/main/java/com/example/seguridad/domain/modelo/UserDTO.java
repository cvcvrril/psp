package com.example.seguridad.domain.modelo;

public record UserDTO(
        Long id,
        String username
) {



}
