package com.example.seguridad.ui.exceptions;

public class NullObjectException extends RuntimeException{
    public NullObjectException(String message) {
        super(message);
    }
}
