package com.example.seguridad.data.modelo.request;


public record AuthenticationRequest(String username, String password) {

}
