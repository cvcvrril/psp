package com.example.graphql.domain.modelo;

public record Mapa(
        int id,
        String nombre
) {
}
