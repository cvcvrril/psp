package com.example.graphql.domain.modelo.graphql;

public record VideojuegoInput(
        int id,
        String titulo
){}
