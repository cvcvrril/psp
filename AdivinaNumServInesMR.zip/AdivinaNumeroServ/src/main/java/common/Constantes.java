package common;

public class Constantes {
    public static final String CONTADOR_KEY = "contador";
    public static final String ADIVINAR_SERVLET = "AdivinarServlet";
    public static final String ADIVINA_VALUE = "/adivina";
    public static final String NUMERO = "numero";
    public static final String MENSAJE = "mensaje";
    public static final String NO_NUM = "Mete un numero, no seas cabezon plis";
    public static final String NO_INTENTOS = "Perdiste, has agotado tus intentos";
    public static final String NUM_REPETIDO = "Venga maquina, has repetido numero";
    public static final String CONTADOR = "contador";
    public static final String HOME = "home";
    public static final String LOSE = "lose";
    public static final String INTENTOS = "intentos";
    public static final String GANA = "gana";
    public static final String NUMERO_ALTO = "El numero es mas alto";
    public static final String REP = "rep";
    public static final String FALLO = "fallo";
    public static final String PREV = "prev";
    public static final String INCOGNITA = "incognita";
}
