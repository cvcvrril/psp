package model.errors;

public class ErrorCOrderItem extends ErrorC{
    public ErrorCOrderItem(String message, int numError) {
        super(message, numError);
    }
}
