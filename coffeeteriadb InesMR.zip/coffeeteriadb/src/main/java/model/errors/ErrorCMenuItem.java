package model.errors;

public class ErrorCMenuItem extends ErrorC{
    public ErrorCMenuItem(String message, int numError) {
        super(message, numError);
    }
}
