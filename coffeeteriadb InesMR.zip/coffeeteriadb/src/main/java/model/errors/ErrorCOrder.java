package model.errors;

public class ErrorCOrder extends ErrorC{
    public ErrorCOrder(String message, int numError) {
        super(message, numError);
    }
}
