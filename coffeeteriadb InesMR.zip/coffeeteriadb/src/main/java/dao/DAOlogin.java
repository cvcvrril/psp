package dao;

import model.Credential;

public interface DAOlogin {
    boolean doLogin(Credential credential);

}
