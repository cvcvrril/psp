Extras añadidos al trabajo:

>Trabajo realizado con la base de datos del restaurante (usando JDBC)
>Programa subido al Payara del instituto (se puede comprobar tanto en las pruebas del Postman como en los artefactos
 del servidor
>Se han usado variables para realizar las pruebas de Postman