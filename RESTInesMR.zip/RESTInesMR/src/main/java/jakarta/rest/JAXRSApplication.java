package jakarta.rest;


import jakarta.ConstantsJakarta;
import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath(ConstantsJakarta.API)
public class JAXRSApplication extends Application {


}
