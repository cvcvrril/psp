package jakarta;

public class ConstantsJakarta {
    public static final String ORDERS_PATH = "/orders";
    public static final String ID_PATH = "/{id}";
    public static final String ID = "id";
    public static final String MENU_ITEM = "/menu_item";
    public static final String API = "/api";
    public static final String TABLES = "/tables";
}
