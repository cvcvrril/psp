package domain.modelo.excepciones;

public class BaseCaidaException extends RuntimeException{
    public BaseCaidaException(String message){
        super(message);
    }

}
