package common;

public class Configuration {
}
