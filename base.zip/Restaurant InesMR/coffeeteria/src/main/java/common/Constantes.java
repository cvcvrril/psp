package common;

public class Constantes {

    public static final String USER_ADDED = "User added";
    public static final String USER_DELETED = "User deleted";
    public static final String ID_C = "id_c";
    public static final String FIRST_NAME = "FirstName";
    public static final String SECOND_NAME = "SecondName";
    public static final String CUSTOMER_UPDATED = "Customer updated";
    public static final String SUCCESFULLY_RESET = "Succesfully reset";
    public static final String USUARIO_O_CONTRASENA_INCORRECTOS = "Usuario o contraseña incorrectos";
    public static final String THE_ORDER_HAS_BEEN_ADDED = "The order has been added";
    public static final String THE_MENU_ITEM_HAS_BEEN_ADDED = "The menu item has been added";
    public static final String THE_MENU_ITEM_HAS_BEEN_REMOVED = "The menu item has been removed";
    public static final String ORDER_DELETED = "Order deleted";
    public static final String ID_ORD = "id_ord";
    public static final String ID_CO = "id_co";
    public static final String ID_TABLE = "id_table";
    public static final String OR_DATE = "or_date";
    public static final String ORDER_UPDATED = "Order updated";

}
