package model.errors;

public class ErrorC {

    /*Atributos*/

    private String message;
    private int num_error;
}
