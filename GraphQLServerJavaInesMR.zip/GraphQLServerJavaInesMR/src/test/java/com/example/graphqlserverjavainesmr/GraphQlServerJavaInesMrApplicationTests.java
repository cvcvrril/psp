package com.example.graphqlserverjavainesmr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraphQlServerJavaInesMrApplicationTests {

    @Test
    void contextLoads() {
    }

}
