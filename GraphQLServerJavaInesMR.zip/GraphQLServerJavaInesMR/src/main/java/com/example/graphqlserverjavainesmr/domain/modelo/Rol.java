package com.example.graphqlserverjavainesmr.domain.modelo;

public record Rol (int id, String rol) {}
