package com.example.graphqlserverjavainesmr.domain.modelo.graphql;

public record VideojuegoInput(
        int id,
        String nombre
){}
