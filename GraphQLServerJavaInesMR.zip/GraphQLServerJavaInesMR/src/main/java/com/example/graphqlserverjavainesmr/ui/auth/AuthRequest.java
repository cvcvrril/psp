package com.example.graphqlserverjavainesmr.ui.auth;


public record AuthRequest(String username, String password) {

}
