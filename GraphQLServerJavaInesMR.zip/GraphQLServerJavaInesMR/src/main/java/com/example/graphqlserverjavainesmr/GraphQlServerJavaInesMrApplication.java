package com.example.graphqlserverjavainesmr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GraphQlServerJavaInesMrApplication {

    public static void main(String[] args) {
        SpringApplication.run(GraphQlServerJavaInesMrApplication.class, args);
    }

}
