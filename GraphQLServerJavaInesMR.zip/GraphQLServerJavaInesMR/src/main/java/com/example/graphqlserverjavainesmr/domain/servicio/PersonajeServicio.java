package com.example.graphqlserverjavainesmr.domain.servicio;

import com.example.graphqlserverjavainesmr.domain.modelo.Personaje;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonajeServicio {
    public List<Personaje> getPersonajes() {
        return null;
    }
}
