package com.example.graphqlserverjavainesmr.domain.modelo;

public class Personaje {
}
